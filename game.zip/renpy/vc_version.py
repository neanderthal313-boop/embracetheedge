branch = 'fix'
nightly = True
official = True
version = '8.2.1.24020302'
version_name = '64bit Sensation'
